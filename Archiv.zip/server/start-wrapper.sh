#!/bin/bash
sleep 5
node /home/admin/PriceList/server/server.js
